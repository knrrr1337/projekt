class Dolgozo():
    def __init__(self,vnev,knev,):
        self.vnev = vnev
        self.knev = knev